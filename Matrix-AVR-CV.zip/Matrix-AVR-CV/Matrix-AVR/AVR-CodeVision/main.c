/*****************************************************
This program was produced by the
CodeWizardAVR V2.05.0 Professional
Automatic Program Generator
� Copyright 1998-2010 Pavel Haiduc, HP InfoTech s.r.l.
http://www.hpinfotech.com

Project :   Matrix 
Version :   1.1 
Date    :   2012/03/31
Author  :   Fattah-Tafreshi 
Company :   vaf-o-t 
Comments:   fattah.roland@gmail.com 


Chip type               : ATmega32
Program type            : Application
AVR Core Clock frequency: 8.000000 MHz
Memory model            : Small
External RAM size       : 0
Data Stack size         : 512
*****************************************************/

#include <mega32.h>
#include <delay.h>

#define clock   PORTC.0
#define strobe  PORTC.1
#define data    PORTC.2

#include "74595.c"       // include 74595 for shiftregister


/*
//  Pixel Code:
flash unsigned char gif_code[]=
{

}
*/

#include "data.h"

#define set_row(x)  PORTD=x

#define ROWS    16
#define COLUMNS 4

unsigned char dbuffer[ROWS][COLUMNS]={0};


const unsigned char dig[]={1,2,4,8,16,32,64,128};

void init(void);
void frame_to_buffer(long);
void refresh(void);


//---------------------------------------------------------------------------------------------------

void main(void)
{
long t=0;
long n=0;
char speed=15;

    init();
    ic74595_init(); 

while (1)
      {
        frame_to_buffer(n);
        refresh();
        if(t++>=image_delay[n]/speed) {t=0;if(n++>=image_frame_count-1) n=0;} 
      }
}

//---------------------------------------------------------------------------------------------------

void frame_to_buffer(long frame)
{
long count = (ROWS * COLUMNS)*(frame);
long i,j;

for(i = 0; i < ROWS; i++)
    {
        for(j = 0; j < COLUMNS; j++)
            {
                dbuffer[i][j] = image_code[count];
                count++;
            }
    }
}

//---------------------------------------------------------------------------------------------------

void refresh(void)
{
char i=0;
char buffer[8];

   for(i=0;i<=7;i++)
      {
         buffer[0]=dbuffer[i][0];
         buffer[1]=dbuffer[i][1];
         buffer[2]=dbuffer[i][2];
         buffer[3]=dbuffer[i][3];
         buffer[4]=dbuffer[i+8][0];
         buffer[5]=dbuffer[i+8][1];
         buffer[6]=dbuffer[i+8][2];
         buffer[7]=dbuffer[i+8][3];  
         
         ic74595_shift_send(buffer,8);
         set_row(dig[i]);
         delay_us(1000);
         set_row(0); 
         
      }
}

//---------------------------------------------------------------------------------------------------

void init(void)
{
// Declare your local variables here

// Input/Output Ports initialization
// Port A initialization
// Func7=In Func6=In Func5=In Func4=In Func3=In Func2=In Func1=In Func0=In 
// State7=T State6=T State5=T State4=T State3=T State2=T State1=T State0=T 
PORTA=0x00;
DDRA=0x00;

// Port B initialization
// Func7=In Func6=In Func5=In Func4=In Func3=In Func2=In Func1=In Func0=In 
// State7=T State6=T State5=T State4=T State3=T State2=T State1=T State0=T 
PORTB=0x00;
DDRB=0x00;

// Port C initialization
// Func7=Out Func6=Out Func5=Out Func4=Out Func3=Out Func2=Out Func1=Out Func0=Out 
// State7=0 State6=0 State5=0 State4=0 State3=0 State2=0 State1=0 State0=0 
PORTC=0x00;
DDRC=0xFF;

// Port D initialization
// Func7=Out Func6=Out Func5=Out Func4=Out Func3=Out Func2=Out Func1=Out Func0=Out 
// State7=0 State6=0 State5=0 State4=0 State3=0 State2=0 State1=0 State0=0 
PORTD=0x00;
DDRD=0xFF;

// Timer/Counter 0 initialization
// Clock source: System Clock
// Clock value: Timer 0 Stopped
// Mode: Normal top=0xFF
// OC0 output: Disconnected
TCCR0=0x00;
TCNT0=0x00;
OCR0=0x00;

// Timer/Counter 1 initialization
// Clock source: System Clock
// Clock value: Timer1 Stopped
// Mode: Normal top=0xFFFF
// OC1A output: Discon.
// OC1B output: Discon.
// Noise Canceler: Off
// Input Capture on Falling Edge
// Timer1 Overflow Interrupt: Off
// Input Capture Interrupt: Off
// Compare A Match Interrupt: Off
// Compare B Match Interrupt: Off
TCCR1A=0x00;
TCCR1B=0x00;
TCNT1H=0x00;
TCNT1L=0x00;
ICR1H=0x00;
ICR1L=0x00;
OCR1AH=0x00;
OCR1AL=0x00;
OCR1BH=0x00;
OCR1BL=0x00;

// Timer/Counter 2 initialization
// Clock source: System Clock
// Clock value: Timer2 Stopped
// Mode: Normal top=0xFF
// OC2 output: Disconnected
ASSR=0x00;
TCCR2=0x00;
TCNT2=0x00;
OCR2=0x00;

// External Interrupt(s) initialization
// INT0: Off
// INT1: Off
// INT2: Off
MCUCR=0x00;
MCUCSR=0x00;

// Timer(s)/Counter(s) Interrupt(s) initialization
TIMSK=0x00;

// USART initialization
// USART disabled
UCSRB=0x00;

// Analog Comparator initialization
// Analog Comparator: Off
// Analog Comparator Input Capture by Timer/Counter 1: Off
ACSR=0x80;
SFIOR=0x00;

// ADC initialization
// ADC disabled
ADCSRA=0x00;

// SPI initialization
// SPI disabled
SPCR=0x00;

// TWI initialization
// TWI disabled
TWCR=0x00;
}