/*
	Fattah-Tafreshi
	2012
	fattah.roland@gmail.com
*/



#ifndef clock
#define clock   PORTC.0
#define strobe  PORTC.1
#define data    PORTC.2
#endif

//-----------------------------------------------------------------------------------------

void ic74595_init()
{
    clock=0;
    strobe=0;
    data=0;
}

//-----------------------------------------------------------------------------------------

void ic74595_load_reg(void)
{
    strobe=1;
    delay_us(1);
    strobe=0;
} 

//-----------------------------------------------------------------------------------------

void ic74595_send_byte(unsigned char dt)
{
 unsigned char i;

 for(i = 0; i < 8; i++)           // Send 8 bits
    {
     if(dt & 0x80)
       {     
        data=1;
        delay_us(1);
       }
     else
       {
        data=0;
        delay_us(1);
       }

     clock=1;        //Clock
     delay_us(1);
     clock=0;
 
     dt <<= 1;                // Get next bit into MSB position       
   }
}

//-----------------------------------------------------------------------------------------

void ic74595_shift_send(char *d,char size)
{
int i=0;
    for(i=size;i>=0;i--)
        ic74595_send_byte(d[i]);
        
        delay_us(1);
        ic74595_load_reg();
}

//-----------------------------------------------------------------------------------------