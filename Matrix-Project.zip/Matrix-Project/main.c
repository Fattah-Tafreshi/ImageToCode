/*
   Fattah-Tafreshi
   email:fattah.roland@gmail.com
   2011
*/

// const unsigned char Code[X/2][2]=

#include "main.h"
#include "matrix.c"

//------------------------------------------------------------------------------

void init();
void control();
signed int8 get_int2();

//------------------------------------------------------------------------------
//Interrupt
#int_RTCC
void  RTCC_isr(void) 
{
   matrix_refresh();
}

//------------------------------------------------------------------------------

void main()
{
   init();
   matrix_init();
   delay_ms(20);
   matrix_speed=24;
   matrix_to_left();
   matrix_color=3;

   while(true)
      {
         control();
         delayms(1);
      }
}  

//------------------------------------------------------------------------------

void init()
{
   setup_wdt(WDT_OFF);
   setup_timer_0( RTCC_INTERNAL | RTCC_8_BIT | RTCC_DIV_32);
   
   setup_adc (ADC_CLOCK_DIV_8);
   setup_adc_ports (AN0);
   set_adc_channel (0);
   
   set_tris_b(0);
   output_b(0);
   set_tris_d(0);
   output_d(0);
   
   
   enable_interrupts(INT_RTCC);
   enable_interrupts(GLOBAL);
   
   printf("Welcome\n\r");
} 

//------------------------------------------------------------------------------

void control()
{
unsigned char c=0;

              if(kbhit())
                  {
                      c=tolower(getc());
                      
                      switch(c)
                        {
                           case '-':{matrix_speed++;printf("\fSpeed: %u",matrix_speed);}
                              break;
                           case '+':{matrix_speed--;printf("\fSpeed: %u",matrix_speed);}
                              break;
                           case 'l':{matrix_speed=22;matrix_to_left();}//14
                              break;
                           case 'r':{matrix_speed=24;matrix_to_right();}//16
                              break;
                           case 'i':invert=~invert;
                              break;
                           case 'q':{delay_refresh+=10;printf("\fDelay=%lu",delay_refresh);}   
                              break;
                           case 'w':{delay_refresh-=10;printf("\fDelay=%lu",delay_refresh);}
                              break;
                           case 'p':matrix_pause=~matrix_pause;
                              break;
                           case '0':matrix_color=0;
                              break;
                           case '1':matrix_color=1;
                              break;
                           case '2':matrix_color=2;
                              break;
                           case '3':matrix_color=3;
                              break;
                           case '4':matrix_color=4;
                              break;
                           case '5':matrix_color=5;
                              break;
                           case '6':matrix_color=6;
                              break;
                           case '7':matrix_color=7;
                              break; 
                           case '8':matrix_color=8;
                              break;                               
                           case '[':if(++num>=size) num=0;
                              break;
                           case ']':if(--num<=0) num=size;
                              break;
                           case 'h':delay_refresh=600;//1000;
                              break;
                           case 'j':delay_refresh=500;
                              break;
                           case 'k':delay_refresh=100;
                              break;
                           case 'a':reset_cpu();
                              break;
                           default:   
                        }
                     
                      c=0;
                      
                  }
}



