/*
   Fattah-Tafreshi
   email:fattah.roland@gmail.com
   2011
   
   Columns Refresh
*/

#include "data.c"
#define  display 4

#define EXP_OUT_CLOCK    PIN_D0
#define EXP_OUT_DO1      PIN_D1
#define EXP_OUT_DO2      PIN_D3
#define EXP_OUT_ENABLE   PIN_D2

#define NUMBER_OF_74595 display * 2

#include "74595.c"

#define TOLEFT  0
#define TORIGHT 1

//------------------------------------------------------------------------------

int8  m=0;
int16 num=0;
int8  matrix_color=2;
int16 nn=0;
int8  matrix_speed=22;
int8  invert=255;
int16 size=0;
int1  matrix_pause=0;

int16 delay_refresh=500;

unsigned char mode=0;

//------------------------------------------------------------------------------

void matrix_init();
void matrix_refresh();
void matrix_to_left();
void matrix_to_right();
void refresh();
byte byteinvert(byte value);
void set_col(int8 value);
void shift_to_left(int16 siz);
void shift_to_right(int16 siz);


//------------------------------------------------------------------------------

byte byteinvert(byte value)
 {
    byte a=value;
    byte i=0;
    byte v=0;
    byte l=128;

    for(i=0;i<=7;i++)
        {
            if(a&1)
            v=v+l;
            a=a>>1;
            l=l/2;
        }
        return v;
 }

//------------------------------------------------------------------------------

void set_col(int8 value)
{
   output_b(value);   
}

//------------------------------------------------------------------------------

void refresh()
{
BYTE dt1[NUMBER_OF_74595];
BYTE dt2[NUMBER_OF_74595];
int8 i=0;
int8 sh=1;

#pragma use fast_io(B)
#pragma use fast_io(D)

if(m>7) m=0;

   for(i=0;i<=((display)-1);i++)
      {
        //matrix_color=3;
         
            switch(matrix_color)
            {
               case 0:
                      {
                         dt1[i*2]=~0;dt1[(i*2)+1]=~0;
                         dt2[i*2]=~0;dt2[(i*2)+1]=~0;
                      }
                  break;
                  
               case 1:
                        {
                           dt1[i*2]    =(Code[m+(8* (i) )+(1*num)][1])^invert ;dt1[(i*2)+1]=~0;
                           dt2[i*2]    =(Code[m+(8* (i) )+(1*num)][0])^invert ;dt2[(i*2)+1]=~0;
                        }
                  break;
                  
               case 2:
                         {
                           dt1[i*2]=~0;dt1[(i*2)+1]=Code[m+(8* (i) )+(1*num)][1]^invert ;
                           dt2[i*2]=~0;dt2[(i*2)+1]=Code[m+(8* (i) )+(1*num)][0]^invert ;
                        }
                  break;
                  
               case 3:{
                       dt1[i*2]    =Code[m+(8* (i) )+(1*num)][1]^invert ;
                       dt1[(i*2)+1]=Code[m+(8* (i) )+(1*num)][1]^invert ;
                       
                       dt2[i*2]    =Code[m+(8* (i) )+(1*num)][0]^invert ;
                       dt2[(i*2)+1]=Code[m+(8* (i) )+(1*num)][0]^invert ;
                      }
                  break;
            }   
         }


   write_expanded_outputs(dt1,dt2);
   delay_us(100);
   set_col(sh<<m);
   delay_us(delay_refresh);
   set_col(0);
   m++;

#pragma use fast_io(B) 
#pragma use fast_io(D)
} 
//------------------------------------------------------------------------------

void shift_to_left(int16 siz)
{
   if(!matrix_pause)
   if(++num>=siz) num=0;
}

//------------------------------------------------------------------------------

void shift_to_right(int16 siz)
{
   if(!matrix_pause)
   if(--num<=0) num=siz;
}

//------------------------------------------------------------------------------

void matrix_refresh()
{
             if(nn>matrix_speed) 
             {
                  nn=0;
                  if(mode==0)
                  shift_to_left(size);
                  else
                  shift_to_right(size);
             }
          
            refresh();
              nn++;  
}                  


//------------------------------------------------------------------------------

void matrix_to_left()
{
   mode=toleft;
}

//------------------------------------------------------------------------------

void matrix_to_right()
{
   mode=toright;
}

//------------------------------------------------------------------------------


void delayms(int d)
{
   int i=0;
      for(i=0;i<=254;i++)
         {
            delay_us(d*4); 
         }
}

//------------------------------------------------------------------------------

void matrix_init()
{
   size=(sizeof(Code)/2)-(display*8);
}   

//------------------------------------------------------------------------------


