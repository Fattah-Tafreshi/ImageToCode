/*
	Fattah-Tafreshi
	LED Text Scroll
	2012
	fattah.roland@gmail.com
*/

#define F_CPU 8000000

#include <avr/io.h>
#include <util/delay.h>
#include <avr/interrupt.h>
#include "data.h"

#define port74595	PORTD
#define clock1		PIND0
#define strobe1		PIND1
#define data1		PIND2

#define clock2		PIND3
#define strobe2		PIND4
#define data2		PIND5


uint8_t scroll=0;
uint8_t n=0;

//----------------------------------------------------------------------------------------------


void setcol(uint8_t value)
{
uint8_t i=0;

	for(i=0;i<=7;i++)
		{
			if(value & 0x80)
				port74595 |=1<<data1;
				else
				port74595 &=~1<<data1;

				port74595 |=1<<clock1;

				port74595 &=~1<<clock1;

			value<<=1;
		}
port74595 |=1<<strobe1;

port74595 &=~1<<strobe1;
}

//----------------------------------------------------------------------------------------------

void setrow(uint8_t value)
{
uint8_t i=0;

	for(i=0;i<=7;i++)
		{
			if(value & 0x80)
				port74595 |=1<<data2;
				else
				port74595 &=~1<<data2;

				port74595 |=1<<clock2;

				port74595 &=~1<<clock2;

			value<<=1;
		}
port74595 |=1<<strobe2;
;
port74595 &=~1<<strobe2;
}

//----------------------------------------------------------------------------------------------

void refresh(unsigned char delay)
{
uint8_t i;
			for(i=0;i<=7;i++)
				{
					setcol(1<<i);
					setrow(~Code[i+scroll]);
					_delay_us(2000);
					setrow(~0);
				}

	if(scroll>=(sizeof(Code)-8)) scroll=0;
	if(++n>=delay) {n=0;scroll++;}
}

//----------------------------------------------------------------------------------------------

int main(void)
{

char i=0;

DDRD=0xff;
PORTD=0;


setcol(0);
setrow(~0);

_delay_ms(1000);


	while(1)
		{
			refresh(5);
			
		}


return 0;
}
